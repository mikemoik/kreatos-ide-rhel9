// -*- C++ -*-

//=============================================================================
/**
 *  @file    Atomic_Op_T.h
 *
 *  @author Douglas C. Schmidt <d.schmidt@vanderbilt.edu>
 */
//=============================================================================

#ifndef ACE_ATOMIC_OP_T_H
#define ACE_ATOMIC_OP_T_H
#include /**/ "ace/pre.h"

#include /**/ "ace/config-all.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

template<typename TYPE>
struct ACE_Type_Traits
{
  using parameter_type = const TYPE &;
};

template<>
struct ACE_Type_Traits<bool>
{
  using parameter_type = bool;
};

template<>
struct ACE_Type_Traits<char>
{
  using parameter_type = char;
};

template<>
struct ACE_Type_Traits<signed char>
{
  using parameter_type = signed char;
};

template<>
struct ACE_Type_Traits<unsigned char>
{
  using parameter_type = unsigned char;
};

template<>
struct ACE_Type_Traits<short>
{
  using parameter_type = short;
};

template<>
struct ACE_Type_Traits<unsigned short>
{
  using parameter_type = unsigned short;
};

template<>
struct ACE_Type_Traits<int>
{
  using parameter_type = int;
};

template<>
struct ACE_Type_Traits<unsigned int>
{
  using parameter_type = unsigned int;
};

template<>
struct ACE_Type_Traits<long>
{
  using parameter_type = long;
};

template<>
struct ACE_Type_Traits<unsigned long>
{
  using parameter_type = unsigned long;
};

template<>
struct ACE_Type_Traits<long long>
{
  using parameter_type = long long;
};

template<>
struct ACE_Type_Traits<unsigned long long>
{
  using parameter_type = unsigned long long;
};

template<>
struct ACE_Type_Traits<float>
{
  using parameter_type = float;
};

template<>
struct ACE_Type_Traits<double>
{
  using parameter_type = double;
};

template<>
struct ACE_Type_Traits<long double>
{
  using parameter_type = long double;
};

template<typename TYPE>
struct ACE_Type_Traits<TYPE*>
{
  using parameter_type = TYPE *;
};

/**
 * @class ACE_Atomic_Op_Ex
 *
 * @brief Transparently parameterizes synchronization into basic
 * arithmetic operations.
 *
 * This class is described in an article in the July/August 1994
 * issue of the C++ Report magazine.  It implements a
 * templatized version of the Decorator pattern from the GoF book.
 *
 * ACE_Atomic_Op_Ex objects must be constructed with a reference
 * to an existing lock. A single lock can be shared between
 * multiple ACE_Atomic_Op_Ex objects. If you do not require this
 * ability consider using the ACE_Atomic_Op class instead, which
 * may be able to take advantage of platform-specific
 * optimisations to provide atomic operations without requiring a
 * lock.
 */
template <class ACE_LOCK, typename TYPE>
class ACE_Atomic_Op_Ex
{
public:
  using arg_type = typename ACE_Type_Traits<TYPE>::parameter_type;

  /// Initialize @c value_ to 0.
  ACE_Atomic_Op_Ex (ACE_LOCK & mtx);

  /// Initialize @c value_ to c.
  ACE_Atomic_Op_Ex (ACE_LOCK & mtx, arg_type c);

  // = Accessors.

  /// Atomically pre-increment @c value_.
  TYPE operator++ ();

  /// Atomically post-increment @c value_.
  TYPE operator++ (int);

  /// Atomically increment @c value_ by rhs.
  TYPE operator+= (arg_type rhs);

  /// Atomically pre-decrement @c value_.
  TYPE operator-- ();

  /// Atomically post-decrement @c value_.
  TYPE operator-- (int);

  /// Atomically decrement @c value_ by rhs.
  TYPE operator-= (arg_type rhs);

  /// Atomically compare @c value_ with rhs.
  bool operator== (arg_type rhs) const;

  /// Atomically compare @c value_ with rhs.
  bool operator!= (arg_type rhs) const;

  /// Atomically check if @c value_ greater than or equal to rhs.
  bool operator>= (arg_type rhs) const;

  /// Atomically check if @c value_ greater than rhs.
  bool operator> (arg_type rhs) const;

  /// Atomically check if @c value_ less than or equal to rhs.
  bool operator<= (arg_type rhs) const;

  /// Atomically check if @c value_ less than rhs.
  bool operator< (arg_type rhs) const;

  /// Atomically assign rhs to @c value_.
  ACE_Atomic_Op_Ex<ACE_LOCK, TYPE> &operator= (arg_type rhs);

  /// Atomically assign <rhs> to @c value_.
  ACE_Atomic_Op_Ex<ACE_LOCK, TYPE> &operator= (
    ACE_Atomic_Op_Ex<ACE_LOCK, TYPE> const & rhs);

  /// Exchange value with @a newval.
  TYPE exchange (TYPE newval);

  /// Explicitly return @c value_.
  TYPE value () const;

  /// Dump the state of an object.
  void dump () const;

  /// Declare the dynamic allocation hooks.
  ACE_ALLOC_HOOK_DECLARE;

  /// Manage copying...
  ACE_Atomic_Op_Ex (ACE_Atomic_Op_Ex<ACE_LOCK, TYPE> const &);

  /**
   * Returns a reference to the underlying ACE_LOCK.  This makes it
   * possible to acquire the lock explicitly, which can be useful in
   * some cases if you instantiate the ACE_Atomic_Op_Ex with an
   * ACE_Recursive_Mutex or ACE_Process_Mutex.
   *
   * @note The right name would be lock_, but HP/C++ will choke on that!
   */
  ACE_LOCK & mutex ();

  /**
   * Explicitly return @c value_ (by reference).  This gives the user
   * full, unrestricted access to the underlying value.  This method
   * will usually be used in conjunction with explicit access to the
   * lock.  Use with care ;-)
   */
  TYPE & value_i ();

private:
  /// Type of synchronization mechanism.
  ACE_LOCK & mutex_;

  /// Current object decorated by the atomic op.
  TYPE value_;
};

/**
 * @class ACE_Atomic_Op
 *
 * @brief Transparently parameterizes synchronization into basic
 * arithmetic operations.
 *
 * This class is described in an article in the July/August 1994
 * issue of the C++ Report magazine.  It implements a
 * templatized version of the Decorator pattern from the GoF book.
 *
 * Certain platforms may provide a template specialization for
 * ACE_Atomic_Op <ACE_Thread_Mutex, long> that provides optimized
 * atomic integer operations without actually requiring a mutex.
 */
template <class ACE_LOCK, typename TYPE>
class ACE_Atomic_Op
{
public:
  using arg_type = typename ACE_Type_Traits<TYPE>::parameter_type;

  /// Initialize @c value_ to 0.
  ACE_Atomic_Op ();

  /// Initialize @c value_ to c.
  ACE_Atomic_Op (arg_type c);

  /// Manage copying...
  ACE_Atomic_Op (ACE_Atomic_Op<ACE_LOCK, TYPE> const & c);

  /// Atomically assign @a rhs to @c value_.
  ACE_Atomic_Op<ACE_LOCK, TYPE> & operator= (arg_type rhs);

  /// Atomically assign @a rhs to @c value_.
  ACE_Atomic_Op<ACE_LOCK, TYPE> & operator= (
    ACE_Atomic_Op<ACE_LOCK, TYPE> const & rhs);

  /// Atomically pre-increment @c value_.
  TYPE operator++ ();

  /// Atomically post-increment @c value_.
  TYPE operator++ (int);

  /// Atomically increment @c value_ by rhs.
  TYPE operator+= (arg_type rhs);

  /// Atomically pre-decrement @c value_.
  TYPE operator-- ();

  /// Atomically post-decrement @c value_.
  TYPE operator-- (int);

  /// Atomically decrement @c value_ by @a rhs.
  TYPE operator-= (arg_type rhs);

  /// Atomically compare @c value_ with @a rhs.
  bool operator== (arg_type rhs) const;

  /// Atomically compare @c value_ with @a rhs.
  bool operator!= (arg_type rhs) const;

  /// Atomically check if @c value_ greater than or equal to @a rhs.
  bool operator>= (arg_type rhs) const;

  /// Atomically check if @c value_ greater than @a rhs.
  bool operator> (arg_type rhs) const;

  /// Atomically check if @c value_ less than or equal to @a rhs.
  bool operator<= (arg_type rhs) const;

  /// Atomically check if @c value_ less than @a rhs.
  bool operator< (arg_type rhs) const;

  /// Exchange value with @a newval.
  TYPE exchange (TYPE newval);

  /// Explicitly return @c value_.
  TYPE value () const;

  /// Dump the state of an object.
  void dump () const;

  /// Declare the dynamic allocation hooks.
  ACE_ALLOC_HOOK_DECLARE;

  /**
   * Explicitly return @c value_ (by reference).  This gives the user
   * full, unrestricted access to the underlying value.  This method
   * will usually be used in conjunction with explicit access to the
   * lock.  Use with care ;-)
   */
  TYPE & value_i ();

private:
  /// Type of synchronization mechanism.
  ACE_LOCK own_mutex_;

  /// Underlying atomic op implementation.
  ACE_Atomic_Op_Ex <ACE_LOCK, TYPE> impl_;
};

ACE_END_VERSIONED_NAMESPACE_DECL

#if defined (__ACE_INLINE__)
#include "ace/Atomic_Op_T.inl"
#endif /* __ACE_INLINE__ */

#include "ace/Atomic_Op_T.cpp"

#include /**/ "ace/post.h"
#endif /*ACE_ATOMIC_OP_T_H*/
